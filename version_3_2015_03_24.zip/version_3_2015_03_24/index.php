<?php
    $root = getcwd();    
    include ''.$root.'/trabalho/include/inc_head.php';
    include ''.$root.'/trabalho/include/inc_menu.php';
?>

<h3>Considerações</h3>
Esta página atende as solicitações realizadas pelo professor Rommel Vieira Carneiro, PUC Minas unidade Barreiro.
<br><br>

<div id="proposito">Propósito: Página inicial do trabalho. Irá direcionar o usuário para as demais áreas</div>   
<?php include ''.$root.'/trabalho/include/inc_foot.php'; ?>