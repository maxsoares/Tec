<div id='cssmenu'>
    <ul>
        <li><a href='/index.php'>Home</a></li>
        <li><a href='/cadastro.php'>Cadastro</a></li>
        <li><a href='/relatorio.php'>Relatório</a></li>
        <li><a href='/ajuda'>Ajuda</a></li>
        <li><a href='/sair'>Sair</a></li>
    </ul>
</div>

