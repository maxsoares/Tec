<a href="./trabalho/document/sga_instrucoes.pdf" target="_blank">
    Clique aqui para baixar o arquivo contendo as instruções 
</a>
<div id="foot">Pontifícia Universidade Católica de Minas Gerais</div>
</body>
</html>